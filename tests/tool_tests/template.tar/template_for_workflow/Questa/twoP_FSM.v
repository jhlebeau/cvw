//-----------------------------------------------------
// File Name   : 2 Phase Clock fsm_using_function.v  0 - 3 - 1 - 2 
// with count hold input and odd output
//-----------------------------------------------------
module twoP_FSM (clka, clkb, restart, hold, odd, state);
//-------------Input Ports-----------------------------
input   clka, clkb, restart, hold;
//-------------Output Ports----------------------------
output  odd, state[1:0];
//-------------Input ports Data Type-------------------
wire    clka, clkb, restart, hold;
//-------------Output Ports Data Type------------------
reg     odd;
// reg     odd, state[1:0];
//——————Internal Constants--------------------------
parameter SIZE = 2;
parameter IDLE  = 2'b00, ONE = 2'b01, TWO = 2'b10,  THREE = 2'b11;
//-------------Internal Variables---------------------------
reg   [SIZE-1:0]          state        ;// Seq part of the FSM
wire   [SIZE-1:0]          temp_state   ;// Internal state reg
reg   [SIZE-1:0]          next_state   ;// combo part of FSM
//----------Code startes Here------------------------
assign temp_state = fsm_function(state, hold);
//----------Function for Combo Logic-----------------
function [SIZE-1:0] fsm_function;
  input  [SIZE-1:0] state;
  input  hold;
case(state)
   IDLE: begin
	   if (hold == 1) begin
	     fsm_function = IDLE;
	   end else begin
             fsm_function = THREE;
	   end
         end 
   ONE: begin
	   if (hold == 1) begin
             fsm_function = ONE;
           end else begin
             fsm_function = TWO;
           end
         end
   TWO: begin
          if (hold == 1) begin
             fsm_function = TWO;
           end else begin
             fsm_function = IDLE;
           end
         end
   THREE: begin
	    if (hold == 1) begin
             fsm_function = THREE;
           end else begin
             fsm_function = ONE;
           end
         end
   default : fsm_function = IDLE;
  endcase
endfunction
//----------Seq Logic-----------------------------
always @ (negedge clka)
begin : FSM_SEQ
  if (restart == 1'b1) begin
    next_state <= IDLE;
  end else begin
    next_state <= temp_state;
  end
end
//----------Output Logic——————————————
always @ (negedge clkb)
begin : OUTPUT_LOGIC
  case(next_state)
  IDLE: begin
          state <= next_state;
          odd <= 1'b0;
        end
  ONE: begin
          state <= next_state;
          odd <= 1'b1;
        end
  TWO: begin
          state <= next_state;
          odd <= 1'b0;
          end
  THREE: begin
          state <= next_state;
          odd <= 1'b1;
         end
  endcase
end // End Of Block OUTPUT_LOGIC

endmodule // End of Module twoP_FSM

